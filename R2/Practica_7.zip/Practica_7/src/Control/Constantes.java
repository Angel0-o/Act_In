/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

/**
 *
 * @author alumno
 */
public class Constantes {
    
    public static final String JUEGO_TERMINADO = "FIN";
    public static final int TOTAL_CARTAS = 48;
    public static final String RUTA_IMAGENES = "img\\";
    
}
